package com.amdocs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoDoctorManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
