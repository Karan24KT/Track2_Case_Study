package com.example.employee.demoEmployee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoEmployeeApplication.class, args);
	}

}
