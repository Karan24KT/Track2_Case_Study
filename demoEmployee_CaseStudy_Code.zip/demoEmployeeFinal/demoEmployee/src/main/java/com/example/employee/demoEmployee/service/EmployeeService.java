package com.example.employee.demoEmployee.service;

import java.util.List;

import com.example.employee.demoEmployee.entity.EmployeeDetails;



public  interface EmployeeService {
	
	public EmployeeDetails  addEmployee (EmployeeDetails  employee);
	public List<EmployeeDetails> getAllEmployee();
	 public EmployeeDetails updateEmployee( EmployeeDetails employee,int id);
     public EmployeeDetails getByEmployeeId(int id);
	 public void  deleteEmployee(int id);

}
